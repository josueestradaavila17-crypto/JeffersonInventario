
import 'package:flutter/material.dart';
import 'models/producto.dart';

List<Producto> listaGlobalProductos = [];

class ProductosPage extends StatefulWidget {
  const ProductosPage({super.key});

  @override
  State<ProductosPage> createState() => _ProductosPageState();
}

class _ProductosPageState extends State<ProductosPage> {
  final _formKey = GlobalKey<FormState>();

  final _codigoController = TextEditingController();
  final _nombreController = TextEditingController();
  final _precioController = TextEditingController();

  String? _categoriaSeleccionada;
  double _stockSeleccionado = 10.0;
  Set<String> _estadoSeleccionado = {'Disponible'};
  DateTime _fechaIngresoSeleccionada = DateTime.now();
  bool _perecibleSeleccionado = false;

  final List<String> _categorias = [
    'Abarrotes',
    'Bebidas',
    'Limpieza',
    'Golosinas',
    'Lácteos',
    'Otro'
  ];

  @override
  void dispose() {
    _codigoController.dispose();
    _nombreController.dispose();
    _precioController.dispose();
    super.dispose();
  }

  Future<void> _seleccionarFecha(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _fechaIngresoSeleccionada,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
    );
    if (picked != null && picked != _fechaIngresoSeleccionada) {
      setState(() {
        _fechaIngresoSeleccionada = picked;
      });
    }
  }

  void _registrarProducto() {
    if (_formKey.currentState!.validate()) {
      final nuevoProducto = Producto(
        codigo: _codigoController.text,
        nombre: _nombreController.text,
        categoria: _categoriaSeleccionada!,
        precio: double.parse(_precioController.text),
        stock: _stockSeleccionado.toInt(),
        estado: _estadoSeleccionado.first,
        fechaIngreso: _fechaIngresoSeleccionada,
        perecible: _perecibleSeleccionado,
      );

      setState(() {
        listaGlobalProductos.add(nuevoProducto);
        _limpiarFormulario();
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('¡Producto registrado con éxito!')),
      );
    }
  }

  void _limpiarFormulario() {
    _formKey.currentState?.reset();
    _codigoController.clear();
    _nombreController.clear();
    _precioController.clear();
    setState(() {
      _categoriaSeleccionada = null;
      _stockSeleccionado = 10.0;
      _estadoSeleccionado = {'Disponible'};
      _fechaIngresoSeleccionada = DateTime.now();
      _perecibleSeleccionado = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('InventarioApp - Registro'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        actions: [
          // Contador en el AppBar usando Badge
          Padding(
            padding: const EdgeInsets.only(right: 20.0),
            child: Center(
              child: Badge(
                label: Text('${listaGlobalProductos.length}'),
                child: const Icon(Icons.inventory_2, size: 28),
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Registrar Nuevo Producto',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: _codigoController,
                    keyboardType: TextInputType.number,
                    maxLength: 6,
                    decoration: const InputDecoration(
                      labelText: 'Código del producto (6 dígitos)',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'El código es obligatorio';
                      }
                      if (value.length != 6) {
                        return 'Debe tener exactamente 6 caracteres';
                      }
                      if (int.tryParse(value) == null) {
                        return 'Solo se permiten dígitos numéricos';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _nombreController,
                    textCapitalization: TextCapitalization.words,
                    decoration: const InputDecoration(
                      labelText: 'Nombre del producto',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return 'El nombre es obligatorio';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: _categoriaSeleccionada,
                    decoration: const InputDecoration(
                      labelText: 'Categoría',
                      border: OutlineInputBorder(),
                    ),
                    items: [
                      'Abarrotes',
                      'Bebidas',
                      'Limpieza',
                      'Golosinas',
                      'Lácteos',
                      'Otro'
                    ].map((String cat) {
                      return DropdownMenuItem<String>(
                          value: cat, child: Text(cat));
                    }).toList(),
                    onChanged: (val) =>
                        setState(() => _categoriaSeleccionada = val),
                    validator: (val) =>
                        val == null ? 'Seleccione una categoría' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _precioController,
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      labelText: 'Precio unitario (S/)',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'El precio es obligatorio';
                      }
                      final p = double.tryParse(value);
                      if (p == null || p <= 0) {
                        return 'Debe ser un número mayor que 0';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                          'Cantidad en stock: ${_stockSeleccionado.toInt()}'),
                      Slider(
                        value: _stockSeleccionado,
                        min: 0,
                        max: 100,
                        divisions: 100,
                        label: _stockSeleccionado.toInt().toString(),
                        onChanged: (val) =>
                            setState(() => _stockSeleccionado = val),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      const Text('Estado: '),
                      const SizedBox(width: 16),
                      SegmentedButton<String>(
                        segments: const [
                          ButtonSegment(
                              value: 'Disponible', label: Text('Disponible')),
                          ButtonSegment(
                              value: 'Agotado', label: Text('Agotado')),
                        ],
                        selected: _estadoSeleccionado,
                        onSelectionChanged: (newSel) =>
                            setState(() => _estadoSeleccionado = newSel),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                          'Fecha: ${_fechaIngresoSeleccionada.day}/${_fechaIngresoSeleccionada.month}/${_fechaIngresoSeleccionada.year}'),
                      ElevatedButton.icon(
                        onPressed: () => _seleccionarFecha(context),
                        icon: const Icon(Icons.calendar_today),
                        label: const Text('Fecha Ingreso'),
                      ),
                    ],
                  ),
                  SwitchListTile(
                    title: const Text('¿Producto perecible?'),
                    value: _perecibleSeleccionado,
                    onChanged: (val) =>
                        setState(() => _perecibleSeleccionado = val),
                  ),
                  const SizedBox(height: 20),
                  
                  // Botón Registrar Producto
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Theme.of(context).colorScheme.primary,
                        foregroundColor: Colors.white,
                      ),
                      onPressed: _registrarProducto,
                      child: const Text('Registrar producto',
                          style: TextStyle(fontSize: 16)),
                    ),
                  ),
                  const SizedBox(height: 12),

                  // BOTÓN "LISTAR" para ir a la pantalla de la tabla
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(
                            color: Theme.of(context).colorScheme.primary,
                            width: 2),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const ListaProductosPage(),
                          ),
                        ).then((_) {
                          setState(() {});
                        });
                      },
                      icon: const Icon(Icons.list_alt),
                      label: const Text('Listar Productos',
                          style: TextStyle(fontSize: 16)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}



class ListaProductosPage extends StatelessWidget {
  const ListaProductosPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Lista de Productos Ingresados'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      // Usamos SingleChildScrollView vertical para que la tabla comience arriba
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, // Alineado a la izquierda/arriba
          children: [
            const Text(
              'Productos Registrados en la Jornada',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            listaGlobalProductos.isEmpty
                ? const Padding(
                    padding: EdgeInsets.symmetric(vertical: 40.0),
                    child: Center(
                      child: Text(
                        'No hay productos registrados',
                        style: TextStyle(
                            fontSize: 16,
                            fontStyle: FontStyle.italic,
                            color: Colors.grey),
                      ),
                    ),
                  )
                : SingleChildScrollView(
                    scrollDirection: Axis.horizontal, // Scroll horizontal si la tabla es ancha
                    child: DataTable(
                      columns: const [
                        DataColumn(label: Text('Código')),
                        DataColumn(label: Text('Nombre')),
                        DataColumn(label: Text('Categoría')),
                        DataColumn(label: Text('Precio (S/)')),
                        DataColumn(label: Text('Stock')),
                        DataColumn(label: Text('Estado')),
                      ],
                      rows: listaGlobalProductos.map((producto) {
                        return DataRow(cells: [
                          DataCell(Text(producto.codigo)),
                          DataCell(Text(producto.nombre)),
                          DataCell(Text(producto.categoria)),
                          DataCell(Text(producto.precio.toStringAsFixed(2))),
                          DataCell(Text(producto.stock.toString())),
                          DataCell(Text(producto.estado)),
                        ]);
                      }).toList(),
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}